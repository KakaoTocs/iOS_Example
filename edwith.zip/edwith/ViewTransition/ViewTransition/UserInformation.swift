//
//  UserInformation.swift
//  ViewTransition
//
//  Created by DGSW_TEACHER on 2018. 4. 5..
//  Copyright © 2018년 KakaoTocs. All rights reserved.
//

import Foundation

class UserInformation {
    static let shared: UserInformation = UserInformation()
    
    var name: String?
    var age: String?
}

